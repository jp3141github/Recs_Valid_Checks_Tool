# Python Reconciliation and Validation Tool

This document provides a comprehensive guide to the Python-based Reconciliation and Validation Tool. This tool is designed to be a generic, robust, and efficient solution for performing data quality checks, reconciliation between two data sources, and validation of data against a set of configurable rules.

## 1. Overview

The tool is built with Python and uses a single Excel file for both configuration and as a template for timestamped output. This allows for easy configuration by non-developers and provides a structured, easy-to-follow report of the reconciliation and validation results.

### Key Features

*   **Excel-Based Configuration:** All configurations, including data source paths, rule definitions, and other settings, are managed in a user-friendly Excel file.
*   **Hybrid Rule Ingestion:** Supports both a structured Domain Specific Language (DSL) for defining rules in Excel and optional GenAI-powered natural language rule parsing (using the Claude API).
*   **Comprehensive Reconciliation:** Performs various reconciliation checks, including key matching, value comparisons (with tolerance), fuzzy string matching, and aggregate checks (sum, count, average).
*   **Extensive Validation:** Supports a wide range of data validation checks, such as data type validation, range checks, pattern matching (regex), and list lookups.
*   **Timestamped Excel Output:** Generates a new, timestamped Excel file for each run, containing a detailed summary of the results, a log of all discrepancies, and the original configuration.
*   **Synthetic Data Generation:** Includes a script to generate comprehensive synthetic data for testing and demonstration purposes.

## 2. System Architecture

The tool is composed of the following key components:

*   **`recon_tool.py`:** The main orchestrator script that reads the configuration, runs the engines, and generates the output.
*   **`recon_engine.py`:** The core engine for performing reconciliation checks between two data sources.
*   **`validation_engine.py`:** The engine for performing data validation checks on a single data source.
*   **`genai_helper.py`:** An optional module for integrating with the Claude API to parse natural language rules.
*   **`create_config_template.py`:** A script to generate a blank Excel configuration template.
*   **`generate_synthetic_data.py`:** A script to create synthetic datasets for testing.
*   **`recon_config_template.xlsx`:** The Excel file used for configuration and as a template for the output.

## 3. How to Use the Tool

### 3.1. Prerequisites

*   Python 3.8 or higher
*   The following Python libraries: `pandas`, `numpy`, `openpyxl`
*   (Optional) For GenAI features, an API key for the Claude API and the `anthropic` or `openai` Python library.

### 3.2. Installation

1.  Unzip the provided `recon_tool.zip` file.
2.  Install the required Python libraries:

    ```bash
    pip install pandas numpy openpyxl
    ```

3.  (Optional) For GenAI features, install the Claude library and set your API key as an environment variable:

    ```bash
    pip install anthropic
    export ANTHROPIC_API_KEY="your-claude-api-key"
    ```

### 3.3. Configuration

1.  Open the `recon_config_template.xlsx` file.
2.  **`Config` Sheet:**
    *   Update the `Project Name` and `Run Description`.
    *   Set the `Output Directory` where the result files will be saved.
    *   Provide the correct paths to your `Data Sources` (e.g., `source1_transactions.csv`, `source2_bank_records.csv`).
    *   (Optional) To enable GenAI rule parsing, set `Enable GenAI` to `TRUE` and ensure the `API Key Environment Variable` is set correctly.
3.  **`ColumnMappings` Sheet:**
    *   Define how columns from your two data sources map to each other. This is crucial for reconciliation checks.
4.  **`ReconciliationRules` Sheet:**
    *   Define the rules for reconciling your two data sources. You can use the structured format or write rules in the `Natural Language Rule` column if GenAI is enabled.
5.  **`ValidationRules` Sheet:**
    *   Define the rules for validating your data. Similar to reconciliation rules, you can use the structured format or natural language.

### 3.4. Running the Tool

Execute the `recon_tool.py` script from your terminal, passing the path to your configuration file as an argument:

```bash
python recon_tool.py /path/to/your/recon_config.xlsx
```

The tool will then:

1.  Read the configuration from your Excel file.
2.  Load the specified data sources.
3.  Execute the defined reconciliation and validation rules.
4.  Generate a new, timestamped Excel file in the specified output directory with the results.

## 4. Rule Ingestion

The tool offers a flexible, hybrid approach to defining rules:

### 4.1. Structured Rule Definition (DSL)

This is the primary and most robust method. You define rules by filling in the columns in the `ReconciliationRules` and `ValidationRules` sheets. The `RuleGuide` sheet in the Excel template provides a detailed reference for all available `Check Type` and `Tolerance Type` options.

**Example (Reconciliation Rule):**

| Rule ID  | Rule Name             | Active | Source 1                 | Source 2                 | Key Column (S1) | Key Column (S2) | Check Type   | Compare Column (S1) | Compare Column (S2) | Tolerance | Tolerance Type |
| :------- | :-------------------- | :----- | :----------------------- | :----------------------- | :-------------- | :-------------- | :----------- | :------------------ | :------------------ | :-------- | :------------- |
| RECON002 | Amount Reconciliation | TRUE   | source1_transactions.csv | source2_bank_records.csv | transaction_id  | ref_id          | value_equals | amount              | transaction_amount  | 0.01      | percentage     |

### 4.2. GenAI-Powered Natural Language Rules

If you have enabled the GenAI feature, you can simply write your rules in plain English in the `Natural Language Rule` column. The tool will use the Claude API to parse your rule and convert it into the structured format for execution.

**Example (Validation Rule):**

| Rule ID | Rule Name | Active | Data Source | Column | Check Type | Parameter 1 | Natural Language Rule                               |
| :------ | :-------- | :----- | :---------- | :----- | :--------- | :---------- | :-------------------------------------------------- |
| VAL-NL1 |           | TRUE   |             |        |            |             | The amount in the validation data must be positive. |

## 5. Output

For each run, the tool generates a new Excel file with a name like `YourProjectName_YYYYMMDD_HHMMSS.xlsx`. This file contains:

*   All the original configuration sheets.
*   **`OutputSummary`:** A high-level summary of the reconciliation and validation results.
*   **`ReconResults`:** A detailed log of all reconciliation discrepancies.
*   **`ValidationResults`:** A detailed log of all validation failures.
*   **`ExecutionLog`:** A log of the tool's execution steps, including any errors or warnings.

This self-contained output file serves as a complete audit trail for each run.

## 6. Included Files

The provided `recon_tool.zip` archive contains:

*   `recon_tool.py`: The main script.
*   `recon_engine.py`, `validation_engine.py`, `genai_helper.py`, `create_config_template.py`, `generate_synthetic_data.py`: Supporting Python modules.
*   `recon_config_template.xlsx`: The Excel configuration template.
*   `data/`: A directory with synthetic data files.
*   `output/`: A directory where output files will be generated.
*   `README.md`: This documentation file.
